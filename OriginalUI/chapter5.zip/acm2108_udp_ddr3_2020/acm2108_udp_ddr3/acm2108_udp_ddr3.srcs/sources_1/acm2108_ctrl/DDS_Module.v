/***************************************************
*	Module Name		:	DDS_Module		   
*	Engineer		:	С÷��
*	Target Device	:	EP4CE10F17C8
*	Tool versions	:	Quartus II 13.0
*	Create Date		:	2017-06-25
*	Revision		:	v1.1
*	Description		:  DDS����ģ�飬����Ƶ�ʿ����ֺ���λ�����ֲ�����Ӧ�����������
**************************************************/

module DDS_Module(
	Clk,
	Rst_n,
	EN,
	MODE,
	DA_Clk,
	DA_Data
);

	input Clk;/*ϵͳʱ��*/
	input Rst_n;/*ϵͳ��λ*/
	input EN;/*DDSģ��ʹ��*/
	input [4:0]MODE;
	
	output DA_Clk;/*DA�������ʱ��*/
	output reg [7:0] DA_Data;/*D������ֲ�������*/
	
	wire [7:0] wave_sin, wave_square, wave_triangle;
	
	reg [31:0]Fword;/*Ƶ�ʿ�����*//*Fword = 2^^N * Fout / Fclk;*/
	reg [31:0]Fre_acc;	
	reg [7:0]Rom_Addr;
	
	reg [1:0] wave_a, wave_b;//��ǰͨ���Ĳ�������
	
	always @ (posedge Clk or negedge Rst_n)
	begin
		if (!Rst_n)
			Fword <= 32'd42950;
		else
			case (MODE)
				5'd0,  5'd1,  5'd2	:	Fword <= 32'd42950;		//1.25k				
				5'd3,  5'd4,  5'd5	:	Fword <= 32'd429500;	//12.5k
				5'd6,  5'd7,  5'd8	:	Fword <= 32'd2147484;	//62.5k
				5'd9,  5'd10, 5'd11	:	Fword <= 32'd4295000;	//125k
				5'd12, 5'd13, 5'd14	:	Fword <= 32'd21474840;	//625k
				5'd15, 5'd16, 5'd17	:	Fword <= 32'd42950000;	//1.25m
				5'd18, 5'd19, 5'd20	:	Fword <= 32'd214748400;	//6.25m
				5'd21, 5'd22, 5'd23	:	Fword <= 32'd429500000;	//12.5m
			endcase
	end
	
	always @ (posedge Clk or negedge Rst_n)
	begin
		if (!Rst_n)
            DA_Data <= wave_sin;
		else
			case (MODE)
				5'd0,5'd3,5'd6,5'd9,5'd12,5'd15,5'd18,5'd21: DA_Data <= wave_sin;
				5'd1,5'd4,5'd7,5'd10,5'd13,5'd16,5'd19,5'd22: DA_Data <= wave_square;
				5'd2,5'd5,5'd8,5'd11,5'd14,5'd17,5'd20,5'd23: DA_Data <= wave_triangle;
			endcase
	end

/*---------------��λ�ۼ���------------------*/	
	always @(posedge Clk or negedge Rst_n)
	if(!Rst_n)
		Fre_acc <= 32'd0;
	else if(!EN)
		Fre_acc <= 32'd0;	
	else 
		Fre_acc <= Fre_acc + Fword;

/*----------���ɲ��ұ���ַ---------------------*/		
	always @(posedge Clk or negedge Rst_n)
	if(!Rst_n)
		Rom_Addr <= 8'd0;
	else if(!EN)
		Rom_Addr <= 8'd0;
	else
		Rom_Addr <= Fre_acc[31:24];	

/*----------�������ұ�ROM-------*/		
	sin_rom_a8d8 ddsrom_sin(
		.addr(Rom_Addr),
		.clk(Clk),
		.q(wave_sin)
	);
	
	square_wave_rom_a8d8 ddsrom_square(
		.addr(Rom_Addr),
		.clk(Clk),
		.q(wave_square)
	);
	
	triangular_rom_a8d8 ddsrom_triangle(
		.addr(Rom_Addr),
		.clk(Clk),
		.q(wave_triangle)
	);

/*----------���DAʱ��----------*/	
	assign DA_Clk = Clk;

endmodule
