../../../lib/xscugic_sinit.o: xscugic_sinit.c \
 ../../../include/xil_types.h ../../../include/xil_assert.h \
 ../../../include/xil_types.h ../../../include/xparameters.h \
 ../../../include/xparameters_ps.h xscugic.h ../../../include/xstatus.h \
 ../../../include/xil_assert.h ../../../include/xil_io.h \
 ../../../include/xil_printf.h ../../../include/xparameters.h \
 ../../../include/bspconfig.h ../../../include/xstatus.h \
 ../../../include/xpseudo_asm.h ../../../include/xreg_cortexa9.h \
 ../../../include/xpseudo_asm_gcc.h xscugic_hw.h \
 ../../../include/xil_exception.h ../../../include/bspconfig.h

../../../include/xil_types.h:

../../../include/xil_assert.h:

../../../include/xil_types.h:

../../../include/xparameters.h:

../../../include/xparameters_ps.h:

xscugic.h:

../../../include/xstatus.h:

../../../include/xil_assert.h:

../../../include/xil_io.h:

../../../include/xil_printf.h:

../../../include/xparameters.h:

../../../include/bspconfig.h:

../../../include/xstatus.h:

../../../include/xpseudo_asm.h:

../../../include/xreg_cortexa9.h:

../../../include/xpseudo_asm_gcc.h:

xscugic_hw.h:

../../../include/xil_exception.h:

../../../include/bspconfig.h:
